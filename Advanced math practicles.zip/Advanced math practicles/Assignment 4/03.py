# Write a program to check if a year is a leap year.

def chechyear(year):
    if(year%4==0):
        print("Year is a leap year")

chechyear(2023)