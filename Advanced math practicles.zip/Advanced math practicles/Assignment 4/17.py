num = 1
sum = 0
while num <= 10:
    sum += num
    num += 1
print(f"The sum of the first 10 natural numbers is {sum}.")
