# 1. Write a program to check if a number is even or odd.

def eveodd(n):
    if(n%2==0):
        print("Number is even")
    else:
        print("Number is odd")

eveodd(3)