num = 1
while num <= 10:
    print(num)
    num += 1
