grade = float(input("Enter your grade: "))
if grade >= 50:
    print("You passed.")
else:
    print("You failed.")
