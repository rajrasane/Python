# 1. Write a program to check if a number is positive.

def ispos(n):
    if(n>0):
        print("Number is positive")

ispos(2)