sum_squares = 0
for i in range(1, 11):
    sum_squares += i**2
print(f"The sum of the squares of the first 10 natural numbers is {sum_squares}.")
