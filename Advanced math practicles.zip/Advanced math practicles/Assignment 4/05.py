# 2. Write a program to check if a person is eligible to vote (age >= 18).

def checkvote(age):
    if(age>=18):
        print("You are eligible")