for i in range(2, 21, 2):
    print(i)
