num = 1
while num <= 10:
    i = 1
    while i <= 10:
        print(f"{num} ^ {i} = {num ** i}")
        i += 1
    num += 1
