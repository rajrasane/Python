# Write a python program to check whether a given string is number or not using lambda

str = "124ASAWF"

isnum = lambda x : x.isdigit()

print(isnum(str))