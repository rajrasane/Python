# Write a python program to create a lambda function that adds 15 to a given number passed in as an argument , also create a lambda function that multiplies argument x with the argument y and print the results 


x = lambda a : a + 15
print(x(10))

x = lambda x,y : x * y
print(x(24,2))