# Write a python program to find if a given string starts with a given character using lambda

str = 'raj'

first_char = lambda x,y : x==y[0]

print(first_char('m',str))