#Write Python code to find the square of odd numbers from 1 to 20 using while loop.
i = 1
while i <= 20:
    if i % 2 == 1:
        print(i**2)
    i+=1


# 1
# 9
# 25
# 49
# 81
# 121
# 169
# 225
# 289
# 361