#Write python code to display tuple ‘I am Indian and the second letter in this tuple.
tuple1 = ('I','a','m','I','n','d','i','a','n')
print(tuple1)
print(tuple1[1])

# ('I', 'a', 'm', 'I', 'n', 'd', 'i', 'a', 'n')
# a


