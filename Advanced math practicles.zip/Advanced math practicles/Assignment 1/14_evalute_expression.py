# Evaluate following expression on Python.

# (a)	M = [1, 2, 3, 4],Find length M.

# (b)	L= “XY Z”  + “pqr” ,Find L.

# (c)	‘Make In India’ , Find (s[:7]) & (s[:9]).
M = [1, 2, 3, 4]
print("(a) Length of M :",len(M))
L= "XY Z" + "pqr"
print("(b) L :",L)
s = 'Make In India'
print("(c) s[:7] :",s[:7])
print("(c) s[:9] :",s[:9])


# (a) Length of M : 4
# (b) L : XY Zpqr
# (c) s[:7] : Make In
# (c) s[:9] : Make In I
