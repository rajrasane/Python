#Write Python code to find maximum and minimum element in the given list. [7,8,71, 32, 49, -5,7,7,0,1,6)
list1 = [7,8,71, 32, 49, -5,7,7,0,1,6]
print("Maximum element in list:-",max(list1))
print("Minimum element in list:-",min(list1))

# Maximum element in list:- 71
# Minimum element in list:- -5