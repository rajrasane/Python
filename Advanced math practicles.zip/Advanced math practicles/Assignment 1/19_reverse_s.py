#Write Python code to reverse the string S = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].
S = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
S = S[::-1]
print(S)

# [13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3]